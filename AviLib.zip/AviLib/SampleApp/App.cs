// SampleApp.App -- Sample application to demonstrate the use of AviWriter.
//
// Gabriel Boyer
// 08/21/2003

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using AviLib;

namespace SampleApp
{
	class App
	{
		[STAThread]
		static void Main(string[] args)
		{
            try
            {
                string[] bitmaps = Directory.GetFiles(@".\", "*.bmp");

                AviWriter aviWriter = new AviWriter("output.avi", AviCompression.None, 24, 320, 240);

                foreach(string bitmap in bitmaps)
                {
                    aviWriter.WriteFrame(new Bitmap(bitmap));
                }

                aviWriter.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
		}
	}
}
